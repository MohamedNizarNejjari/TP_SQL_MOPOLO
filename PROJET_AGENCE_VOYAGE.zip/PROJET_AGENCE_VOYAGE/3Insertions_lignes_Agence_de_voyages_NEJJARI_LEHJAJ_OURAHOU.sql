Nom, Prénom Participant 1:	Mohamed Nizar NEJJARI		, Activités paricipant1
Nom, Prénom Participant 2:	Mehdi LEHJAJ		        , Activités paricipant2
Nom, Prénom Participant 3:	Yassir OURAHOU		        , Activités paricipant3


---INSERTION TABLE CLIENT---

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (1, 'Dupont', 'Jean', 'jean.dupont@gmail.com', '0123456789');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (3, 'Leclerc', 'Pierre', 'pierre.leclerc@yahoo.com', '0789123456');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (4, 'Bernard', 'Lucie', 'lucie.bernard@outlook.com', '0745632198');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (5, 'Muller', 'Julien', 'julien.muller@gmail.com', '0634128790');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (6, 'Gauthier', 'Isabelle', 'isabelle.gauthier@orange.fr', '0689752314');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (7, 'Moreau', 'Nicolas', 'nicolas.moreau@gmail.com', '0784512369');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (8, 'Rousseau', 'Elise', 'elise.rousseau@yahoo.com', '0756983245');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (9, 'Perez', 'Mathieu', 'mathieu.perez@gmail.com', '0712345698');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (10, 'Simon', 'Chloe', 'chloe.simon@outlook.com', '0648591237');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (11, 'Garcia', 'Jean', 'jean.garcia@gmail.com', '0723456987');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (12, 'Lefevre', 'Julie', 'julie.lefevre@wanadoo.fr', '0768954321');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (13, 'Martinez', 'Sophie', 'sophie.martinez@gmail.com', '0698745231');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (14, 'Blanc', 'Paul', 'paul.blanc@yahoo.com', '0635987412');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (15, 'Dubois', 'Elodie', 'elodie.dubois@gmail.com', '0756214897');

INSERT INTO Client (id_client, nom, prenom, email, telephone) 
VALUES (16, 'Ourahou', 'Yassir', 'yassir.ourahou@gmail.com', '0756214897');

---INSERTION TABLE VOYAGE---

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (1, 'Montpelier', 600.00, TO_DATE('2024-11-18', 'YYYY-MM-DD'), TO_DATE('2024-11-28', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (2, 'Paris', 850.00, TO_DATE('2024-12-01', 'YYYY-MM-DD'), TO_DATE('2024-12-10', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (3, 'Tokyo', 2200.00, TO_DATE('2024-10-25', 'YYYY-MM-DD'), TO_DATE('2024-11-05', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (4, 'New York', 1500.00, TO_DATE('2024-12-15', 'YYYY-MM-DD'), TO_DATE('2024-12-25', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (5, 'Rome', 900.00, TO_DATE('2024-11-01', 'YYYY-MM-DD'), TO_DATE('2024-11-07', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (6, 'Madrid', 650.00, TO_DATE('2024-11-10', 'YYYY-MM-DD'), TO_DATE('2024-11-15', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (7, 'Londres', 700.00, TO_DATE('2024-12-02', 'YYYY-MM-DD'), TO_DATE('2024-12-07', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (8, 'Berlin', 800.00, TO_DATE('2024-10-30', 'YYYY-MM-DD'), TO_DATE('2024-11-05', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (9, 'Lisbonne', 550.00, TO_DATE('2024-11-15', 'YYYY-MM-DD'), TO_DATE('2024-11-20', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (10, 'Prague', 750.00, TO_DATE('2024-11-20', 'YYYY-MM-DD'), TO_DATE('2024-11-25', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (11, 'Amsterdam', 720.00, TO_DATE('2024-11-22', 'YYYY-MM-DD'), TO_DATE('2024-11-27', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (12, 'Venise', 980.00, TO_DATE('2024-12-05', 'YYYY-MM-DD'), TO_DATE('2024-12-12', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (13, 'Barcelone', 670.00, TO_DATE('2024-12-08', 'YYYY-MM-DD'), TO_DATE('2024-12-13', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (14, 'Dubaï', 3200.00, TO_DATE('2024-11-28', 'YYYY-MM-DD'), TO_DATE('2024-12-06', 'YYYY-MM-DD'));

INSERT INTO Voyage (id_voyage, destination, prix, date_depart, date_retour) 
VALUES (15, 'Istanbul', 1500.00, TO_DATE('2024-10-25', 'YYYY-MM-DD'), TO_DATE('2024-11-02', 'YYYY-MM-DD'));

---INSERTION TABLE RESERVATION---

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (1, 1, 1, TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (2, 2, 2, TO_DATE('2024-10-17', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (3, 3, 3, TO_DATE('2024-10-16', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (4, 4, 4, TO_DATE('2024-10-15', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (5, 5, 5, TO_DATE('2024-10-18', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (6, 6, 6, TO_DATE('2024-10-19', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (7, 7, 7, TO_DATE('2024-10-20', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (8, 8, 8, TO_DATE('2024-10-21', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (9, 9, 9, TO_DATE('2024-10-22', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (10, 10, 10, TO_DATE('2024-10-23', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (11, 11, 11, TO_DATE('2024-10-24', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (12, 12, 12, TO_DATE('2024-10-25', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (13, 13, 13, TO_DATE('2024-10-26', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (14, 14, 14, TO_DATE('2024-10-27', 'YYYY-MM-DD'));

INSERT INTO Reservation (id_reservation, id_client, id_voyage, date_reservation) 
VALUES (15, 15, 15, TO_DATE('2024-10-28', 'YYYY-MM-DD'));

---INSERTION TABLE RESERVATION---

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (1, 'Martin', 'Claire', 'claire.martin@agencevoyages.com', '0987654321');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (2, 'Dufresne', 'Mathieu', 'mathieu.dufresne@agencevoyages.com', '0645891234');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (3, 'Bouchard', 'Camille', 'camille.bouchard@agencevoyages.com', '0667984523');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (4, 'Renard', 'Julie', 'julie.renard@agencevoyages.com', '0623456897');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (5, 'Morel', 'Antoine', 'antoine.morel@agencevoyages.com', '0689712345');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (6, 'Robin', 'Sophie', 'sophie.robin@agencevoyages.com', '0732154689');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (7, 'Dubois', 'Marc', 'marc.dubois@agencevoyages.com', '0648791235');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (8, 'Giraud', 'Lucie', 'lucie.giraud@agencevoyages.com', '0678932145');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (9, 'Blanc', 'Nicolas', 'nicolas.blanc@agencevoyages.com', '0745698231');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (10, 'Lemoine', 'Claire', 'claire.lemoine@agencevoyages.com', '0756981234');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (11, 'Perrot', 'Jean', 'jean.perrot@agencevoyages.com', '0623987451');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (12, 'Marchand', 'Isabelle', 'isabelle.marchand@agencevoyages.com', '0648571239');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (13, 'Leclerc', 'Marie', 'marie.leclerc@agencevoyages.com', '0667852394');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (14, 'Simon', 'Julien', 'julien.simon@agencevoyages.com', '0632587941');

INSERT INTO Agent_voyage (id_agent, nom, prenom, email, telephone) 
VALUES (15, 'Rousseau', 'Pierre', 'pierre.rousseau@agencevoyages.com', '0674895123');

---INSERTION TABLE VOL---

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (1, 1, 'Air France', 'AF1234', TO_TIMESTAMP('08:30:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (2, 2, 'British Airways', 'BA5678', TO_TIMESTAMP('09:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (3, 3, 'Japan Airlines', 'JL9876', TO_TIMESTAMP('12:45:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (4, 4, 'Delta Airlines', 'DL1357', TO_TIMESTAMP('14:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (5, 5, 'Lufthansa', 'LH3345', TO_TIMESTAMP('07:30:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (6, 6, 'Iberia', 'IB2233', TO_TIMESTAMP('13:30:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (7, 7, 'British Airways', 'BA1234', TO_TIMESTAMP('18:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (8, 8, 'Ryanair', 'FR5678', TO_TIMESTAMP('10:15:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (9, 9, 'EasyJet', 'EJ3456', TO_TIMESTAMP('17:45:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (10, 10, 'Air France', 'AF4321', TO_TIMESTAMP('12:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (11, 11, 'KLM', 'KL9876', TO_TIMESTAMP('15:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (12, 12, 'Vueling', 'VY4567', TO_TIMESTAMP('09:30:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (13, 13, 'Swiss', 'LX1234', TO_TIMESTAMP('06:45:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (14, 14, 'Emirates', 'EK9876', TO_TIMESTAMP('21:00:00', 'HH24:MI:SS'));

INSERT INTO Vol (id_vol, id_voyage, compagnie, numero_vol, heure_depart) 
VALUES (15, 15, 'Turkish Airlines', 'TK4567', TO_TIMESTAMP('23:30:00', 'HH24:MI:SS'));

---INSERTION TABLE HOTEL---

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (1, 1, 'Le Meurice', '228 Rue de Rivoli, Paris', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (2, 2, 'Hilton Paris Opera', '108 Rue Saint-Lazare, Paris', 4);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (3, 3, 'Park Hyatt Tokyo', '3-7-1-2 Nishi Shinjuku, Tokyo', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (4, 4, 'The Plaza', '768 5th Avenue, New York', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (5, 5, 'Hotel de Russie', 'Via del Babuino 9, Rome', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (6, 6, 'Hotel Ritz Madrid', 'Plaza de la Lealtad 5, Madrid', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (7, 7, 'The Savoy', 'Strand, Londres', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (8, 8, 'Hotel Adlon Kempinski', 'Unter den Linden 77, Berlin', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (9, 9, 'Four Seasons Hotel Ritz', 'Rua Rodrigo da Fonseca 88, Lisbonne', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (10, 10, 'Augustine', 'Letenská 12, Prague', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (11, 11, 'Hotel de l''Europe', 'Nieuwe Doelenstraat 2-14, Amsterdam', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (12, 12, 'Gritti Palace', 'Campo Santa Maria del Giglio, Venise', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (13, 13, 'Hotel Arts', 'Marina 19-21, Barcelone', 5);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (14, 14, 'Burj Al Arab', 'Jumeirah Beach Road, Dubaï', 7);

INSERT INTO Hotel (id_hotel, id_voyage, nom_hotel, adresse, nb_etoiles) 
VALUES (15, 15, 'Four Seasons', 'Tevkifhane Sokak, Sultanahmet, Istanbul', 5);



*/