
Nom, Prenom Participant 1:	Mohamed Nizar NEJJARI		, Activites paricipant1
Nom, Prenom Participant 2:	Mehdi LEHJAJ		        , Activites paricipant2
Nom, Prenom Participant 3:	Yassir OURAHOU		        , Activites paricipant3



-------Requetes de mise a jour--------

---Requete impliquant 1 table---
---Modifier le numero de telephone du client existant dans la table 'Client'---

     UPDATE Client
     SET telephone = '0789123457'
     WHERE id_client = 2;


---Requete impliquant 1 table
---de la mise a jour le prix un voyage dans la table 'Voyage'---

     UPDATE Voyage
     SET prix = 950.00
     WHERE id_voyage = 2;


---Requete impliquant 2 tables---
---Mettre a jour adresse de hotel en fonction de identifiant du voyage dans les tables 'Voyage' et 'Hotel'---

     UPDATE Hotel
     SET adresse = '12 Rue Saint-Lazare, Paris'
     WHERE id_voyage = (SELECT id_voyage FROM Voyage WHERE destination = 'Paris');


---Requete impliquant 2 tables---
---Modifier email de agent de voyage en fonction de ID de agent et de son nom---

     UPDATE Agent_voyage
     SET email = 'new.email@agencevoyages.com'
     WHERE id_agent = 3 AND nom = 'Bouchard';


---Requete impliquant plus de 2 tables---
---Mettre a jour le numero de telephone du client dont la reservation est liee a un voyage dans une destination specifique---

     UPDATE Client
     SET telephone = '0712345678'
     WHERE id_client = (SELECT id_client FROM Reservation WHERE id_voyage = (SELECT id_voyage FROM Voyage WHERE destination = 'Tokyo'));


---Requete impliquant plus de 2 tables
---Mettre a jour le prix du voyage reserve par un client specifique---

     UPDATE Voyage
     SET prix = 2400.00
     WHERE id_voyage = (SELECT id_voyage FROM Reservation WHERE id_client = 3);


--------Requetes de consultation--------

---Requete impliquant 1 table (simple)
---Selectionner tous les clients dans la table `Client`.

     SELECT * FROM Client;


---Requete impliquant 1 table avec un `GROUP BY`
---Compter le nombre de reservations par voyage dans la table `Reservation`.

     SELECT id_voyage, COUNT(*) AS nb_reservations
     FROM Reservation
     GROUP BY id_voyage;


---Requete impliquant 1 table avec un 'ORDER BY'---
---Selectionner les voyages tries par prix decroissant---

     SELECT * FROM Voyage
     ORDER BY prix DESC;


---Requete impliquant 2 tables avec jointure interne---
---Selectionner le nom des clients et les destinations de leurs reservations---

     SELECT Client.nom, Voyage.destination
     FROM Client
     INNER JOIN Reservation ON Client.id_client = Reservation.id_client
     INNER JOIN Voyage ON Reservation.id_voyage = Voyage.id_voyage;


---Requete impliquant 2 tables avec jointure externe---
---Selectionner tous les voyages et leurs eventuelles reservations (incluant ceux sans reservation)---

     SELECT Voyage.destination, Reservation.id_reservation
     FROM Voyage
     LEFT JOIN Reservation ON Voyage.id_voyage = Reservation.id_voyage;


---Requete impliquant 2 tables avec 'GROUP BY'---
---Compter le nombre de clients par voyage reserve---

     SELECT Voyage.destination, COUNT(Reservation.id_client) AS nb_clients
     FROM Voyage
     INNER JOIN Reservation ON Voyage.id_voyage = Reservation.id_voyage
     GROUP BY Voyage.destination;


---Requete impliquant 2 tables avec 'ORDER BY'---
---Selectionner les clients et les dates de reservation, tries par date de reservation croissante---

     SELECT Client.nom, Reservation.date_reservation
     FROM Client
     INNER JOIN Reservation ON Client.id_client = Reservation.id_client
     ORDER BY Reservation.date_reservation ASC;


---Requete impliquant plus de 2 tables avec jointures internes---
---Selectionner le nom des clients, le nom des hotels ou ils sejourneront, et les dates de depart des voyages---

     SELECT Client.nom, Hotel.nom_hotel, Voyage.date_depart
     FROM Client
     INNER JOIN Reservation ON Client.id_client = Reservation.id_client
     INNER JOIN Voyage ON Reservation.id_voyage = Voyage.id_voyage
     INNER JOIN Hotel ON Voyage.id_voyage = Hotel.id_voyage;

---Requete impliquant plus de 2 tables avec jointure externe---
---Selectionner toutes les destinations de voyage et les informations de vol, y compris les voyages sans vols associes---

     SELECT Voyage.destination, Vol.numero_vol, Vol.compagnie
     FROM Voyage
     LEFT JOIN Vol ON Voyage.id_voyage = Vol.id_voyage;


---Requete impliquant plus de 2 tables avec 'GROUP BY'---
---Compter le nombre de vols par compagnie aerienne pour chaque destination---

     SELECT Voyage.destination, Vol.compagnie, COUNT(Vol.id_vol) AS nb_vols
     FROM Voyage
     INNER JOIN Vol ON Voyage.id_voyage = Vol.id_voyage
     GROUP BY Voyage.destination, Vol.compagnie;

---Requete impliquant plus de 2 tables avec 'ORDER BY'---
---Selectionner les clients, leurs voyages, et les hotels associes, tries par prix de voyage decroissant---

     SELECT Client.nom, Voyage.destination, Hotel.nom_hotel, Voyage.prix
     FROM Client
     INNER JOIN Reservation ON Client.id_client = Reservation.id_client
     INNER JOIN Voyage ON Reservation.id_voyage = Voyage.id_voyage
     INNER JOIN Hotel ON Voyage.id_voyage = Hotel.id_voyage
     ORDER BY Voyage.prix DESC;

---Requete impliquant plus de 2 tables avec jointure interne, group by et tri---
---Selectionner les hotels et le nombre de clients sejournant dans chaque hotel, tries par nombre de clients decroissant---

     SELECT Hotel.nom_hotel, COUNT(Client.id_client) AS nb_clients
     FROM Hotel
     INNER JOIN Voyage ON Hotel.id_voyage = Voyage.id_voyage
     INNER JOIN Reservation ON Voyage.id_voyage = Reservation.id_voyage
     INNER JOIN Client ON Reservation.id_client = Client.id_client
     GROUP BY Hotel.nom_hotel
     ORDER BY nb_clients DESC;


*/