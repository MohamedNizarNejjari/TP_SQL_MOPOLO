Nom, Prenom Participant 1:	Mohamed Nizar NEJJARI		, Activites paricipant1
Nom, Prenom Participant 2:	Mehdi LEHJAJ		        , Activites paricipant2
Nom, Prenom Participant 3:	Yassir OURAHOU		        , Activites paricipant3

---- Nombres limites de reservation par un seul client ----

CREATE OR REPLACE TRIGGER TRG_LIMIT_RESERVATIONS
BEFORE INSERT ON Reservation
FOR EACH ROW
DECLARE
  v_nb_reservations NUMBER;
BEGIN
  -- Compter le nombre de reservations existantes pour ce client
  SELECT COUNT(*) INTO v_nb_reservations
  FROM Reservation
  WHERE id_client = :NEW.id_client;

  -- Si le nombre de reservations est egal ou superieur a 5, empecher l'insertion
  IF v_nb_reservations >= 5 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Un client ne peut pas avoir plus de 5 reservations actives.');
  END IF;
END;

---- Nombres maximales des etoiles ----

CREATE OR REPLACE TRIGGER TRG_VALIDATE_HOTEL_STARS
BEFORE UPDATE OF nb_etoiles ON Hotel
FOR EACH ROW
BEGIN

  -- Verifier que le nombre d'etoiles est entre 1 et 5
  IF :NEW.nb_etoiles < 1 OR :NEW.nb_etoiles > 5 THEN
    RAISE_APPLICATION_ERROR(-20002, 'Le nombre detoiles doit etre compris entre 1 et 5.');
  END IF;
END;

