Nom, Prénom Participant 1:	Mohamed Nizar NEJJARI		, Activités paricipant1
Nom, Prénom Participant 2:	Mehdi LEHJAJ		        , Activités paricipant2
Nom, Prénom Participant 3:	Yassir OURAHOU		        , Activités paricipant3

/*==============================================================*/
/* Nom de SGBD :  MySQL 5.0                                     */
/* Date de cr�ation :  09/10/2024 00:28:29                      */
/*==============================================================*/


drop table if exists Agent_voyage;

drop table if exists Client;

drop index INDEX_HOTEL_VOYAGE on Hotel;

drop table if exists Hotel;

drop index INDEX_RESERVATION_VOYAGE on Reservation;

drop index INDEX_RESERVATION_CLIENT on Reservation;

drop table if exists Reservation;

drop index INDEX_VOL_VOYAGE on Vol;

drop table if exists Vol;

drop table if exists Voyage;

/*==============================================================*/
/* Table : Agent_voyage                                         */
/*==============================================================*/
create table Agent_voyage
(
   id_agent             NUMBER(9) not null,
   nom                  VARCHAR2(50) not null,
   prenom               VARCHAR2(50) not null,
   email                VARCHAR2(100),
   telephone            VARCHAR2(20),
   constraint           PK_AGENT_VOYAGE primary key (id_agent)
);

/*==============================================================*/
/* Table : Client                                               */
/*==============================================================*/
create table Client
(
   id_client            NUMBER(9) not null,
   nom                  VARCHAR2(50) not null,
   prenom               VARCHAR2(50) not null,
   email                VARCHAR2(100),
   telephone            VARCHAR2(20),
   constraint           PK_CLIENT primary key (id_client)
);

/*==============================================================*/
/* Table : Hotel                                                */
/*==============================================================*/
create table Hotel
(
   id_hotel             NUMBER(9) not null,
   id_voyage            NUMBER(9) not null,
   nom_hotel            VARCHAR2(100) not null,
   adresse              VARCHAR2(200),
   nb_etoiles           NUMBER(1),
   constraint           PK_HOTEL primary key (id_hotel)
);

/*==============================================================*/
/* Index : INDEX_HOTEL_VOYAGE                                   */
/*==============================================================*/
create index INDEX_HOTEL_VOYAGE on Hotel
(
   
);

/*==============================================================*/
/* Table : Reservation                                          */
/*==============================================================*/
create table Reservation
(
   id_reservation       NUMBER(9) not null,
   id_client            NUMBER(9) not null,
   id_voyage            NUMBER(9) not null,
   date_reservation     DATE,
   constraint           PK_RESERVATION primary key (id_reservation)
);

/*==============================================================*/
/* Index : INDEX_RESERVATION_CLIENT                             */
/*==============================================================*/
create index INDEX_RESERVATION_CLIENT on Reservation
(
   
);

/*==============================================================*/
/* Index : INDEX_RESERVATION_VOYAGE                             */
/*==============================================================*/
create index INDEX_RESERVATION_VOYAGE on Reservation
(
   
);

/*==============================================================*/
/* Table : Vol                                                  */
/*==============================================================*/
create table Vol
(
   id_vol               NUMBER(9) not null,
   id_voyage            NUMBER(9) not null,
   compagnie            VARCHAR2(100) not null,
   numero_vol           VARCHAR2(20) not null,
   heure_depart         TIMESTAMP,
   constraint           PK_VOL primary key (id_vol)
);

/*==============================================================*/
/* Index : INDEX_VOL_VOYAGE                                     */
/*==============================================================*/
create index INDEX_VOL_VOYAGE on Vol
(
   
);

/*==============================================================*/
/* Table : Voyage                                               */
/*==============================================================*/
create table Voyage
(
   id_voyage            NUMBER(9) not null,
   destination          VARCHAR2(100) not null,
   prix                 DECIMAL(10,2),
   date_depart          DATE,
   date_retour          DATE,
   id_agent             NUMBER(9),
   constraint           PK_VOYAGE primary key (id_voyage)
);

alter table Hotel add constraint FK_HOTEL_VOYAGE foreign key (id_voyage)
      references Voyage (id_voyage);

alter table Reservation add constraint FK_RESERVATION_CLIENT foreign key (id_client)
      references Client (id_client);

alter table Reservation add constraint FK_RESERVATION_VOYAGE foreign key (id_voyage)
      references Voyage (id_voyage);

alter table Vol add constraint FK_VOL_VOYAGE foreign key (id_voyage)
      references Voyage (id_voyage);

alter table Voyage add constraint FK_VOYAGE_AGENT_VOYAGE foreign key (id_agent)
      references Agent_voyage (id_agent);

